fx_version 'cerulean'
game 'gta5'
author 'HUEHUE'
description 'kassat'
version '1.0.0'


client_scripts {
    'client/*.lua',
    'configs/*.lua',
}

server_scripts {
    'server/*.lua',
    'configs/*.lua',
}


