Locales = { 
    ['FI'] = {
        ["robb_text"] = "Paina ~b~E ~w~varastaaksesi",
        ["not_enough_police"] = "Ei tarpeeksi poliiseja",
        ["shafe_police_alert"] = "Henkilö näpisti kauapsta!",
        ["police_alert"] = "Kauppa ryöstö",
        ["alerblip_name"] = "Kauppa ryöstö",
        ["policealert_title"] = "valvontakamera",
        ["need_item"]= "Tarvitset tiirikan!"

    },

}